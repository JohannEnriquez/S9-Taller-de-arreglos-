package Fecha;

public class PruebaFecha {
    public static void main(String[] args) {

        Fecha fechaActual = new Fecha();

        System.out.print("La fecha actual es: ");
        System.out.println(fechaActual.toString());
    }
}