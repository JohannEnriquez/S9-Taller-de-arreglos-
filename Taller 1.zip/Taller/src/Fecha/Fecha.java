package Fecha;
import java.util.Calendar;
public class Fecha {
    private int mes;
    private int dia;
    private int año;
    public Fecha() {
        Calendar calendario = Calendar.getInstance();
        this.mes = calendario.get(Calendar.MONTH) + 1;
        this.dia = calendario.get(Calendar.DAY_OF_MONTH);
        this.año = calendario.get(Calendar.YEAR);
    }
    public Fecha(int mes, int dia, int año) {
        this.mes = mes;
        this.dia = dia;
        this.año = año;
    }
    public void setMes(int mes) {
        this.mes = mes;
    }
    public int getMes() {
        return mes;
    }
    public void setDia(int dia) {
        this.dia = dia;
    }
    public int getDia() {
        return dia;
    }
    public void setAño(int año) {
        this.año = año;
    }
    public int getAño() {
        return año;
    }
    @Override
    public String toString() {
        return String.format("%02d-%02d-%04d", mes, dia, año);
    }
}