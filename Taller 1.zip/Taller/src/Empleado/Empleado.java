package Empleado;
import java.sql.SQLOutput;
public class Empleado {
    private static int cantidadEmpleados;
    private String primerNombre;
    private String apellidoPaterno;
    private float salarioMensual;
    public Empleado(String primerNombre, String apellidoPaterno, float salarioMensual) {
        this.primerNombre = primerNombre;
        this.apellidoPaterno = apellidoPaterno;
        if (salarioMensual > 0) {
            this.salarioMensual = salarioMensual;
        } else {
            this.salarioMensual = 0;
        }
        cantidadEmpleados++;
    }
    public void setPrimerNombre(String primerNombre) {
        this.primerNombre = primerNombre;
    }
    public String getPrimerNombre() {
        return primerNombre;
    }
    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }
    public String getApellidoPaterno() {
        return apellidoPaterno;
    }
    public void setSalarioMensual(float salarioMensual) {
        if (salarioMensual > 0) {
            this.salarioMensual = salarioMensual;
        }
    }
    public float getSalarioMensual() {
        return salarioMensual;
    }
    public static int getCantidadEmpleados() {
        return cantidadEmpleados;
    }
}