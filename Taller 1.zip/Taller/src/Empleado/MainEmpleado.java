package Empleado;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainEmpleado {
    public static void main(String[] args) {
        List<Empleado> empleados = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Ingresar empleado");
            System.out.println("2. Mostrar salario anual");
            System.out.println("3. Aumentar salario");
            System.out.println("4. Mostrar empleado");
            System.out.println("5. Salir");

            int option = scanner.nextInt();

            switch (option) {
                case 1:
                    System.out.println("Ingrese nombre, apellido y salario mensual:");
                    String nombre = scanner.next();
                    String apellido = scanner.next();
                    float salarioMensual = scanner.nextFloat();
                    Empleado empleado = new Empleado(nombre, apellido, salarioMensual);
                    empleados.add(empleado);
                    break;
                case 2:
                    if (empleados.isEmpty()) {
                        System.out.println("No hay empleados registrados.");
                    } else {
                        for (Empleado e : empleados) {
                            float salarioAnual = e.getSalarioMensual() * 12;
                            System.out.println("Salario anual de " + e.getPrimerNombre() + " " + e.getApellidoPaterno() + ": $" + salarioAnual);
                        }
                    }
                    break;
                case 3:
                    if (empleados.isEmpty()) {
                        System.out.println("No hay empleados registrados.");
                    } else {
                        for (Empleado e : empleados) {
                            e.setSalarioMensual((float) (e.getSalarioMensual() * (1 + 10.0 / 100.0)));
                            System.out.println("Salario anual de " + e.getPrimerNombre() + " " + e.getApellidoPaterno() + " después del aumento: $" + e.getSalarioMensual() * 12);
                        }
                    }
                    break;
                case 4:
                    if (empleados.isEmpty()) {
                        System.out.println("No hay empleados registrados.");
                    } else {
                        for (Empleado e : empleados) {
                            System.out.println("Empleado: " + e.getPrimerNombre() + " " + e.getApellidoPaterno() + ", salario mensual: $" + e.getSalarioMensual());
                        }
                    }
                    break;
                case 5:
                    System.out.println("Adiós!");
                    return;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
            }
        }
    }
}