package Empleado;

import java.util.Scanner;

public class MainArreglos {
    public static void main(String[] args) {
        Empleado[] empleados = new Empleado[100];
        int numEmpleados = 0;
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Ingresar empleado");
            System.out.println("2. Mostrar salario anual");
            System.out.println("3. Aumentar salario");
            System.out.println("4. Mostrar empleado");
            System.out.println("5. Salir");

            int option = scanner.nextInt();

            switch (option) {
                case 1:
                    if (numEmpleados == 100) {
                        System.out.println("No se pueden ingresar más empleados.");
                        break;
                    }
                    System.out.println("Ingrese nombre, apellido y salario mensual:");
                    String nombre = scanner.next();
                    String apellido = scanner.next();
                    float salarioMensual = scanner.nextFloat();
                    Empleado empleado = new Empleado(nombre, apellido, salarioMensual);
                    empleados[numEmpleados] = empleado;
                    numEmpleados++;
                    break;
                case 2:
                    for (int i = 0; i < numEmpleados; i++) {
                        float salarioAnual = empleados[i].getSalarioMensual() * 12;
                        System.out.println("Salario anual de " + empleados[i].getPrimerNombre() + " " + empleados[i].getApellidoPaterno() + ": $" + salarioAnual);
                    }
                    break;
                case 3:
                    for (int i = 0; i < numEmpleados; i++) {
                        empleados[i].setSalarioMensual((float) (empleados[i].getSalarioMensual() * (1 + 10.0 / 100.0)));
                        System.out.println("Salario anual de " + empleados[i].getPrimerNombre() + " " + empleados[i].getApellidoPaterno() + " después del aumento: $" + empleados[i].getSalarioMensual() * 12);
                    }
                    break;
                case 4:
                    for (int i = 0; i < numEmpleados; i++) {
                        System.out.println("Empleado: " + empleados[i].getPrimerNombre() + " " + empleados[i].getApellidoPaterno() + ", salario mensual: $" + empleados[i].getSalarioMensual());
                    }
                    break;
                case 5:
                    System.out.println("Adiós!");
                    return;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
            }
        }
    }
}