package FrecuenciasCardiacas;
import java.time.LocalDate;
import java.time.Period;
public class FrecuenciasCardiacas {
    private String primerNombre;
    private String apellido;
    private LocalDate fechaNacimiento;

    public FrecuenciasCardiacas(String primerNombre, String apellido, int dia, int mes, int anio) {
        this.primerNombre = primerNombre;
        this.apellido = apellido;
        this.fechaNacimiento = LocalDate.of(anio, mes, dia);
    }
    public String getPrimerNombre() {
        return primerNombre;
    }
    public void setPrimerNombre(String primerNombre) {
        this.primerNombre = primerNombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }
    public void setFechaNacimiento(int dia, int mes, int anio) {
        this.fechaNacimiento = LocalDate.of(anio, mes, dia);
    }
    public int getEdad() {
        LocalDate hoy = LocalDate.now();
        Period periodo = Period.between(fechaNacimiento, hoy);
        return periodo.getYears();
    }
    public float getFrecuenciaCardiacaMaxima() {
        return 220 - getEdad();
    }
    public String getFrecuenciaCardiacaEsperada() {
        float minima = (float) (getFrecuenciaCardiacaMaxima() * 0.5);
        float maxima = (float) (getFrecuenciaCardiacaMaxima() * 0.85);
        return minima + " - " + maxima;
    }
}