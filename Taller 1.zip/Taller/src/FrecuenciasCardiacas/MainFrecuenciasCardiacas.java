package FrecuenciasCardiacas;

import java.util.Scanner;
public class MainFrecuenciasCardiacas {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese su primer nombre: ");
        String primerNombre = scanner.nextLine();

        System.out.print("Ingrese su apellido: ");
        String apellido = scanner.nextLine();

        System.out.print("Ingrese su fecha de nacimiento (dd/mm/yyyy): ");
        String fechaNacimientoStr = scanner.nextLine();
        String[] partes = fechaNacimientoStr.split("/");
        int dia = Integer.parseInt(partes[0]);
        int mes = Integer.parseInt(partes[1]);
        int anio = Integer.parseInt(partes[2]);

        FrecuenciasCardiacas fc = new FrecuenciasCardiacas(primerNombre, apellido, dia, mes, anio);

        System.out.println("Información de la persona:");
        System.out.println("Nombre: " + fc.getPrimerNombre());
        System.out.println("Apellido: " + fc.getApellido());
        System.out.println("Fecha de nacimiento: " + fc.getFechaNacimiento());

        System.out.println("Información de frecuencia cardiaca:");
        System.out.println("Edad: " + fc.getEdad());
        System.out.println("Frecuencia cardiaca máxima: " + fc.getFrecuenciaCardiacaMaxima());
        System.out.println("Frecuencia cardiaca esperada: " + fc.getFrecuenciaCardiacaEsperada());
    }
}